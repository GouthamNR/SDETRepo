# 🏆 ISTQB Certification Quick Reference Cheat Sheet

## 📊 3 Levels at a Glance

| Aspect | FOUNDATION | ADVANCED | EXPERT |
|--------|-----------|----------|--------|
| **Exam Questions** | 40 MCQ | 80-100 MCQ | 100-120 MCQ |
| **Duration** | 60 min | 180 min | 240 min |
| **Pass Score** | 65% (26/40) | 65% | 65% |
| **Prerequisite** | None | CTFL + 1-2 yrs | Advanced + 3+ yrs |
| **Cost (India)** | ₹6,254 | ₹6,844 | ₹7,434 |
| **Cost (USA)** | ~$75 | ~$85 | ~$95 |
| **Timeline** | Month 1 | Year 1-2 | Year 3+ |
| **Career Impact** | Entry gate | Mid-career boost | Executive level |

---

## 💰 Salary Progression

### India (LPA - Lakhs Per Annum)
```
Non-Certified → CTFL → CTAL → CTEL
12-15 LPA → 15-18 LPA → 22-30 LPA → 32-45 LPA
```
**Increase**: 10-20% per level

### USA (Annual Salary)
```
Non-Certified → CTFL → CTAL → CTEL
$65-75K → $75-85K → $105-130K → $130-180K
```
**Increase**: 12-25% per level

### ROI Analysis
- **Cost**: ₹6,254 ($75) for Foundation
- **Break-even**: 1-2 months with salary increase
- **5-Year Benefit**: ₹10-15 LPA additional

---

## 3️⃣ FLOWS (Specialization Paths)

### 🔷 CORE FLOW (80% of testers)
- **Path**: Foundation → Advanced (TA/TM/TTA) → Expert
- **Best For**: Waterfall, Traditional, Enterprise
- **Roles**: Test Manager, Test Analyst, Technical Lead

### 🔶 AGILE FLOW (Growing rapidly)
- **Path**: Agile Foundation → Agile Advanced
- **Best For**: Agile, DevOps, Continuous Delivery
- **Roles**: Agile Test Analyst, Agile Test Engineer

### 🔹 SPECIALIST FLOW (High salary, 45% growth)
- **Domains**: AI, Automotive, Game Testing, Acceptance, Security
- **Salary Boost**: +20-30% (specialized roles)
- **Best For**: Domain-specific industries

---

## 📚 CTFL 4.0 Syllabus (Chapter Breakdown)

| Chapter | % | Topics | Questions |
|---------|---|--------|-----------|
| 1. Fundamentals | 20% | Why test, principles, error vs defect | 8 |
| 2. SDLC Testing | 10% | Waterfall, Agile, Static, Dynamic | 4 |
| 3. Static Testing | 10% | Reviews, inspections, analysis | 4 |
| **4. Design Techniques** | **25%** | **EP, BVA, Decision Tables, Coverage** | **10** |
| 5. Test Management | 20% | Planning, risk, monitoring, defects | 8 |
| 6. Test Tools | 15% | Types, automation, selection | 6 |
| **TOTAL** | **100%** | **40 Questions** | **40** |

**⭐ Focus Most on Chapter 4** (25% of exam)

---

## 📋 Advanced Level (CTAL) - 3 Tracks

### 📊 Test Analyst (CTAL-TA)
- **Focus**: Test design, analysis, execution
- **Salary Boost**: +15%
- **Roles**: Senior QA, Test Analyst, QA Lead

### 👔 Test Manager (CTAL-TM)
- **Focus**: Leadership, planning, risk management
- **Salary Boost**: +20-25%
- **Roles**: Test Manager, QA Manager, Test Lead
- **Salary**: Up to $110K (USA), ₹45+ LPA (India)

### 🔧 Technical Test Analyst (CTAL-TTA)
- **Focus**: Automation, code analysis, performance
- **Salary Boost**: +18-20%
- **Roles**: SDET, Automation Engineer, Technical Lead

---

## 🎯 3-Month Exam Prep Plan

### 📅 Month 1: Foundation
- **Week 1-2**: Study Chapters 1-2
- **Week 3-4**: Study Chapters 3-4
- **Target**: Understand concepts, 50% practice Q's

### 📅 Month 2: Deep Dive
- **Week 1-2**: Study Chapters 5-6
- **Week 3-4**: Review all chapters
- **Target**: 70-75% on practice exams

### 📅 Month 3: Exam Ready
- **Week 1-2**: Revision & weak areas
- **Week 3**: Mock exams (timed)
- **Week 4**: Take actual exam
- **Target**: 80%+ on mock exams

---

## 📈 Statistics & Market Data

### ISTQB Global Reach
- **500K+** certified testers worldwide
- **100+** countries with ISTQB programs
- **50+** languages available
- **Growing** 15% annually

### Career Benefits
- **60%** get promotion/job offer within 6 months
- **38%** of certified work in global companies (vs 21% non-certified)
- **28%** better chance of senior roles with Advanced
- **93%** of employers value ISTQB
- **20%** productivity increase in organizations with certified testers
- **30%** reduction in bug-fixing costs

### Job Market
- **45%** increase in specialist testing roles (5 years)
- **80%** choose Core Flow
- **Growing** demand for Agile Flow
- **High demand** for specialist skills (AI, Security)

---

## 💡 10 Key Exam Tips

1. **Read Carefully** - 60 min for 40 Q = 1.5 min per question
2. **Skip & Return** - Don't get stuck on hard questions
3. **Flag Difficult** - Mark for review at end
4. **Eliminate** - Remove obviously wrong options first
5. **First Instinct** - Usually correct, don't overthink
6. **Time Buffer** - Save 5-10 min for review
7. **"All of Above"** - Rarely correct
8. **"None of Above"** - Sometimes correct
9. **Sleep Well** - Before exam night
10. **Test Setup** - Verify internet if online exam

---

## 🎯 Action Timeline

| When | What | Goal |
|------|------|------|
| **Month 1** | Take CTFL exam | Get certified |
| **Month 2-6** | Gain experience | Apply learning |
| **Month 6** | Promotion/raise arrives | +15-20% salary |
| **Year 1** | Decide on CTAL track | Choose specialization |
| **Year 1-2** | Gain 1-2 yrs experience | Meet prerequisites |
| **Year 2** | Take CTAL exam | Advanced certified |
| **Year 2-3** | Senior role | Leadership position |
| **Year 3+** | Consider CTEL | Expert level |

---

## 🚀 Future Trends (Next 2-3 Years)

### ✨ New Certifications Coming
- 🤖 **AI Testing** (CT-AI) - High demand, +25-30% salary
- ☁️ **Cloud Testing** - Microservices, Kubernetes
- 🔐 **Security Testing** (CT-Security) - Growing critical
- 📱 **Digital Testing** - IoT, wearables, edge computing

### 🔮 QA Evolution
- AI-powered test generation & analytics
- Shift-left: Testing from day 1
- Continuous testing in CI/CD
- Security-first approach everywhere

### 💼 Career Implications
- All testers need cloud knowledge
- Security testing becomes mandatory
- AI/ML knowledge increasingly important
- Soft skills (communication, leadership) critical

---

## ❌ Common Mistakes to Avoid

1. ❌ Skip Foundation → It's mandatory prerequisite
2. ❌ Cram last minute → Study consistently for 3 months
3. ❌ Only memorize → Understand concepts
4. ❌ Skip practice exams → Must do 500+ practice questions
5. ❌ Ignore weak chapters → Chapter 4 is 25% of exam
6. ❌ Rush during exam → Read questions carefully
7. ❌ Don't review → Use last 5-10 minutes for review
8. ❌ Ignore salary data → It motivates and justifies investment

---

## 📚 Study Resources

### Free Resources
- ✓ Official ISTQB Syllabus (istqb.org)
- ✓ YouTube tutorials (Simplilearn, Edureka)
- ✓ Online forums and study groups
- ✓ Sample questions from ISTQB

### Paid Resources
- ✓ Online training courses ($200-500)
- ✓ Practice exam engines (1000+ questions)
- ✓ Study guides and books
- ✓ Instructor-led training ($500-1000)

### Recommended Providers
- Simplilearn, Edureka, Linux Academy
- Local ISTQB Accredited Training Partners
- Check istqb.org for authorized providers

---

## 🎓 Why ISTQB Matters

### For You (Individual)
✓ Proven competency certification
✓ Career advancement guarantee
✓ Higher salary (10-20% boost)
✓ Global job opportunities
✓ Confidence in your skills

### For Companies
✓ Quality improvement (20% productivity)
✓ Cost reduction (30% less bugs)
✓ Better team communication
✓ Process standardization
✓ Reduced risk

### For QA Industry
✓ Professional standards
✓ Consistent knowledge
✓ Industry credibility
✓ Talent pool development

---

## 🏁 Your Next Steps

1. **This Week**: Download CTFL syllabus from istqb.org
2. **Week 2**: Enroll in accredited training course
3. **Week 3**: Start studying (3-month plan)
4. **Month 3**: Register for exam
5. **Month 4**: Celebrate getting certified! 🎉

---

**Remember**: 
- ISTQB is a **passport to QA careers**
- It's **not hard, just requires consistency**
- **60% of testers get promotion within 6 months**
- **ROI break-even in 1-2 months**
- **Your investment: ₹6,254 ($75) | Your return: ₹2-3 LPA ($3-4K) annually**

**You've got this! 💪**