# Complete Testing Types Quick Reference Guide

## Master Cheat Sheet for All Testing Types

---

## 1️⃣ FUNCTIONAL TESTING TYPES

### Unit Testing
- **What**: Individual module/component testing
- **Who**: Developers
- **Type**: White Box Testing (code visibility)
- **When**: During development, before integration
- **Scope**: Single function/method
- **Example**: Test login function with valid/invalid credentials

### Integration Testing
- **What**: Testing interaction between multiple modules
- **Who**: Developers + QA
- **Type**: Gray Box Testing (partial code knowledge)
- **When**: After unit testing
- **Approaches**: 
  - Top-Down (high-level first)
  - Bottom-Up (low-level first)
  - Big Bang (combine all at once)
- **Example**: Verify debit & credit between accounts in fund transfer

### System Testing
- **What**: End-to-end testing of complete integrated system
- **Who**: QA Testers
- **Type**: Black Box Testing (no code visibility)
- **When**: After integration testing complete
- **Environment**: Production-like test environment
- **Focus**: Business workflows, complete scenarios
- **Example**: Test entire loan approval process from application to disbursement

### User Acceptance Testing (UAT)
- **What**: Final testing by end-users/business stakeholders
- **Who**: Business users, Domain experts, Customers
- **When**: After system testing passes quality gates
- **Types**:
  - **Alpha Testing**: At developer site
  - **Beta Testing**: At customer site
- **Purpose**: Validate business requirements & real-time data
- **Example**: Fed-Ex employees test payment with actual Fed-Ex workflows

---

### Smoke Testing (Build Verification)
- **What**: Quick sanity check of basic features
- **When**: IMMEDIATELY when new build received
- **Duration**: 30 minutes to 2 hours
- **Scope**: Basic/critical features only - POSITIVE testing only
- **Goal**: Verify build is testable before deep testing
- **Decision**: If FAIL → reject build immediately
- **Key Point**: Saves tremendous time if blocking defects exist
- **Example**: Check if app launches, login works, homepage loads

**💡 Pro Tip**: Smoke test failure means building to dev team immediately!

### Sanity Testing
- **What**: Deep testing of very critical features
- **Difference from Smoke**: Narrow & Deep vs Wide & Shallow
- **When**: Need to thoroughly verify critical functionality
- **Approach**: Manual, unscripted (experience-based)
- **Example**: Thoroughly test Banking App Login, Amount Transfer, Balance Check

### Regression Testing
- **What**: Testing existing features after changes/bug fixes
- **When**: After every new build with modifications
- **Why Critical**: One bug fix can break multiple features
- **Types**:
  - **Unit Regression**: Only changed code
  - **Regional Regression**: Changed code + impact areas (recommended)
  - **Full Regression**: Entire application (time-consuming)
- **Automation**: HIGHLY RECOMMENDED to automate (QTP, Selenium, etc.)

**⚠️ Reality**: Manual regression testing → monotonous, error-prone, time-consuming

### Retesting
- **What**: Testing a specific bug fix to verify defect is fixed
- **When**: After developer marks bug as FIXED
- **Scope**: Only the particular defect
- **Difference from Regression**: Retesting ≠ Regression Testing

| Aspect | Retesting | Regression Testing |
|--------|-----------|-------------------|
| Scope | Specific bug fixed | Entire application/modules |
| Purpose | Verify bug fixed | Ensure fixes don't break other features |
| Planned | Yes, after each fix | Yes, comprehensive plan |

### End-to-End Testing
- **What**: Complete business workflow from start to finish
- **Scope**: All features, all systems, complete user journey
- **Data**: Real-like production data
- **Example**: Registration → Account Setup → Money Deposit → Transfer → Report → Download

### Ad-Hoc Testing (Monkey Testing/Gorilla Testing)
- **What**: Random testing without predefined procedures
- **Why**: End-users behave unpredictably, not systematically like testers
- **When**: In spare time after formal testing OR when interesting scenarios found
- **Approach**: Behave like end-user, test random flows, unexpected combinations
- **Document**: Record findings for future reference

**💡 Reality Check**: Ad-hoc often catches bugs that systematic testing misses!

**Example Scenarios**:
- Login → Immediately click Back (should NOT show inbox)
- Copy-paste URL → Logout → Access URL again (should NOT work)
- Access deleted resource → Should show "Resource not found"

### Exploratory Testing
- **What**: Simultaneous test design and execution without pre-planned cases
- **Who**: Experienced testers with product knowledge
- **When**: Requirements unclear OR exploring application behavior
- **Advantage**: Adapts to findings real-time, learns as testing progresses
- **Document**: Even unscripted, document findings

### Mutation Testing
- **What**: Developers intentionally inject defects
- **Purpose**: Verify tester quality and test case effectiveness
- **How**: Developers add bugs → Testers test → If caught = good tests; If not caught = weak tests
- **Benefit**: Ensures testing team quality

### Exhaustive Testing
- **What**: Testing ALL positive AND negative scenarios
- **When**: Critical features where quality is paramount
- **Reality**: Often impossible due to combinatorial explosion
- **Example**: 15 fields × 5 values each = 30+ billion combinations!

---

## 2️⃣ NON-FUNCTIONAL TESTING TYPES

### Performance Testing
- **What**: Response time, throughput, resource usage under NORMAL conditions
- **Measures**: Response time, CPU, Memory, Disk I/O, Network bandwidth
- **Tools**: LoadRunner, JMeter, Gatling
- **Acceptance**: Response time < 2 seconds for user actions
- **When**: After system testing

### Load Testing
- **What**: Application under HEAVY CONCURRENT LOAD
- **Purpose**: Find maximum users application can handle
- **Example**: Simulate 1000 concurrent users on banking portal
- **Metrics**: Response time degradation, failure rate at peak load
- **Goal**: Identify bottlenecks BEFORE going live

### Stress Testing
- **What**: Application BEYOND maximum capacity to find breaking point
- **Purpose**: Where does system fail? How gracefully?
- **Scenarios**: Double expected load, hardware failures, network issues
- **Expected**: System handles gracefully OR fails with appropriate messages (not crash)

**Example**: If 1000 users → stress test 2000-5000 users

### Usability Testing
- **What**: How user-friendly and intuitive is the application?
- **Focus**: UI design, navigation, colors, fonts, layout, UX
- **Questions**: 
  - Can users complete tasks easily?
  - Is interface clear?
  - Are buttons positioned intuitively?
- **Who**: Non-technical users (end-users provide best feedback)
- **Tools**: Standard GUI checklists

### Compatibility Testing
- **What**: Application works across different platforms, OSes, browsers, devices
- **Platforms**: Windows, Mac, Linux, Mobile, etc.
- **Browsers**: Chrome, Firefox, IE, Safari, Edge
- **Devices**: Desktop, Laptop, Tablet, Mobile, Smartwatch
- **Strategy**: Focus on most-used platforms (ROI approach)

**Real Case**: AutoCAD tested on Windows 2000 but customers used XP, NT, 98 → Bugs appeared

### Security Testing
- **What**: Prevent unauthorized access, protect sensitive data
- **Tests**: 
  - SQL Injection attempts
  - Cross-Site Scripting (XSS)
  - Authentication/Authorization bypass
  - Data encryption validation
- **Tools**: Burp Suite, OWASP ZAP, Nessus
- **Who**: Security specialists

### Reliability Testing
- **What**: Application functions correctly continuously for extended periods
- **Duration**: Hours/Days to test stability
- **How**: Automated scripts run 100,000+ iterations
- **Metric**: Mean Time Between Failures (MTBF)
- **Example**: Mobile phone after 10 days may hang due to RAM buildup

### Recovery Testing
- **What**: Application recovers properly from crashes/failures
- **Scenarios**:
  - Sudden power failure during transaction
  - Network disconnection mid-process
  - Database server crash
  - Disk full error
- **Expected**: Restore to previous state + log error messages
- **Example**: Firefox shows restore session option after power loss

### Authorization Testing
- **What**: Users have proper access levels (who can do what)
- **Example**: Admin → all features, Paid User → limited, Free User → none

### Authentication Testing (Confidentiality)
- **What**: System recognizes registered users, provides correct information
- **Example**: Only registered users can access personal data

### GUI Testing
- **What**: Visual interface design and layout
- **Checks**:
  - Alignment of objects
  - Font sizes, styles, colors consistent
  - No broken frames
  - No scattered content
  - No object overlapping
  - Professional appearance

### Accessibility Testing
- **What**: Application usable by handicapped/disabled people
- **For**: Blind users (screen readers), deaf users (captions), physically disabled
- **Standards**: WCAG (Web Content Accessibility Guidelines)

### Globalization Testing

#### Internationalization (I18N)
- **What**: Content translation to different languages
- **How**: Use property files for each language (not translators)
- **Test**: Check correct language displays in correct place
- **Bug Example**: Select Japanese but Chinese displays (wrong property file connection)

#### Localization (L10N)
- **What**: Region-specific formats
- **Tests**:
  - **Date Format**: US = MM/DD/YYYY, India = DD/MM/YYYY
  - **Currency**: $ vs Rs vs €
  - **Pincode**: Some have characters (AB100)
  - **Images**: Different images for different countries

---

## 3️⃣ QUICK REFERENCE: WHEN TO USE WHICH TESTING

| Scenario | Use This Testing | Why? |
|----------|-----------------|------|
| New build received | **Smoke Testing** | Quick check - save time if broken |
| Bug fix received | **Retesting + Regression** | Verify fix + ensure nothing broke |
| Web app for 10 countries | **Globalization Testing** | Verify all languages & formats |
| App for mobile users | **Compatibility + Performance** | Different devices & network speeds |
| Banking application | **Security + Reliability** | Critical for money transactions |
| Website slow? | **Performance + Load Testing** | Find bottlenecks & max capacity |
| Before go-live | **All types comprehensive** | Ensure production-ready quality |

---

## 4️⃣ TESTING LEVELS VS TYPES COMPARISON

| Aspect | Testing Levels | Testing Types |
|--------|----------------|---------------|
| **What are they?** | Stages in SDLC | Categories based on what we're testing |
| **Examples** | Unit, Integration, System, UAT | Functional, Non-Functional, Performance |
| **Sequence** | Sequential (one after another) | Can happen at any level |
| **Scope** | Increases through levels | Defined by testing type |
| **Who does it?** | Developers → Testers → Users | Testers, QA specialists |

---

## 5️⃣ COST OF DEFECTS ACROSS PHASES

| Phase | Relative Cost | Impact |
|-------|---------------|--------|
| **Requirements** | $1 | Minimal - Easy to fix |
| **Design** | $10 | Low - Still manageable |
| **Development (Unit)** | $50 | Medium - Code changes |
| **System Testing** | $100 | High - Multiple rework |
| **UAT Phase** | $200 | Very High - Delay risk |
| **🚨 Production (Live)** | **$1,000+** | **Critical - Business impact** |

**💰 Key Takeaway**: Testing is an INVESTMENT not a cost - saves 10-100x in production!

---

## 6️⃣ DEFECT LIFECYCLE FLOWCHART

1. **OPEN** - Test engineer finds bug, creates defect report
2. **ASSIGNED** - Development lead assigns to developer
3. **FIXED** - Developer fixes bug
4. **CLOSED** - Test engineer verifies fix, marks CLOSED
5. **REOPEN** - If bug still exists, marks REOPEN
6. **REJECT** - Developer rejects (not a bug, wrong config, old requirements)
7. **DUPLICATE** - Same bug already being fixed
8. **CANNOT FIX** - Not possible to fix or limitation
9. **POSTPONED** - Fixed in future release/version

---

## 7️⃣ TESTING TIME ALLOCATION

| Activity | Typical % of Time |
|----------|------------------|
| Test Execution | 80% |
| Test Case Writing | 10% |
| Test Planning & Design | 5% |
| Defect Reporting | 3% |
| Review & Meetings | 2% |

**🎯 Reality**: Most time spent executing tests, not planning!

---

## 8️⃣ INTERVIEW Q&A

### Q: What's difference between Smoke and Sanity Testing?
**A:** 
- **Smoke**: Wide & Shallow - test all critical features quickly
- **Sanity**: Narrow & Deep - thoroughly test specific critical features

### Q: Functional vs Non-Functional Testing?
**A:**
- **Functional**: Does feature work? (WHAT)
- **Non-Functional**: How well does it work? Performance, security, reliability (HOW)

### Q: Regression vs Retesting?
**A:**
- **Retesting**: Did the specific bug fix work?
- **Regression**: Did the fix break anything else?

### Q: Why early testing important?
**A:** Defects found early ($1) vs production ($1000+) = 1000x cost difference

### Q: How many testing types exist?
**A:** 
- **13+ Functional types**
- **14+ Non-Functional types**

---

## 9️⃣ COMMON MISTAKES TO AVOID

❌ Starting testing too late → Test from requirements phase
❌ Only positive testing → Always test negative scenarios too
❌ Skipping regression → Bug fix can break other features
❌ No documentation → Test cases enable consistency & transfer
❌ Testing everything equally → Prioritize critical features
❌ "No bugs = Quality" → Just means testing missed bugs

---

## 🔟 KEY STATISTICS

- **80%** of project time = test execution
- **20%** of project time = planning, design, review
- **50%** cost increase per defect in production
- **10x** more cost to fix in production vs development
- **Zero defects exists = False** - all products have bugs

---

## ADVANCED TIPS FOR TESTERS

✅ Master all testing types - know when to use each
✅ Combine Functional + Non-Functional for complete QA
✅ Early testing saves massive money
✅ Regression testing is non-negotiable
✅ Prioritize based on risk & business criticality
✅ Document EVERYTHING
✅ Automate repetitive testing (regression, load)
✅ Manual testing for new features

---

## 📚 RECOMMENDED LEARNING PATH

1. **Foundation**: Understand STLC phases
2. **Basics**: Learn testing levels (Unit → Integration → System → UAT)
3. **Types**: Master all functional & non-functional testing types
4. **Design**: Learn test case design techniques (Equivalence Partitioning, BVA)
5. **Defects**: Understand defect life cycle & bug tracking
6. **Automation**: Learn automation frameworks & tools
7. **Metrics**: Understand test metrics & measurement
8. **Advanced**: Risk-based testing, exploratory techniques

---

## 🎓 CERTIFICATION TOPICS

These testing types are covered in:
- **ISTQB Certification** (Foundation, Advanced)
- **QA Certifications** (CSTE, CSQA)
- **Company-specific QA training**

Understanding all testing types → Professional QA Engineer

---

**Remember**: Testing is not about finding all bugs - it's about preventing defects from reaching production and ensuring quality meets business requirements!

---

*Last Updated: December 2025 | Version 2.0 | Complete Manual Testing Guide*